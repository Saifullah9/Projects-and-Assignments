#include <stdio.h>

#include "./drivers/inc/slider_switches.h"
#include "./drivers/inc/pushbuttons.h"
#include "./drivers/inc/VGA.h"
#include "./drivers/inc/ps2_keyboard.h"
#include "./drivers/inc/audio.h"

void test_char() {
	int x,y;
	char c = 0;
	
	for (y=0; y<=59; y++) {
		for (x=0; x<=79; x++) {
			VGA_write_char_ASM(x, y, c++);
		}
	}
}

void test_byte() {
	int x,y;
	char c = 0;
	
	for (y=0; y<=59; y++) {
		for (x=0; x<=79; x+=3) {
			VGA_write_byte_ASM(x, y, c++);
		}
	}
}

void test_pixel() {
	int x,y;
	unsigned short colour = 0;
	
	for (y=0; y<=239; y++) {
		for (x=0; x<=319; x++) {
			VGA_draw_point_ASM(x,y,colour++);
		}
	}
}

void vga() {

	//clear screen
	VGA_clear_charbuff_ASM();
	VGA_clear_pixelbuff_ASM();
	
	while (1) {
		int pb_data = read_PB_data_ASM();
		int slider_data = read_slider_switches_ASM();

		//Push Button 0
		if (pb_data == 1){
			if(slider_data == 0) {
				test_char();
			}
			else {
				test_byte();
			}
		}
		//Push Button 1
		else if (pb_data == 2) {
			test_pixel();
		}
		//Push Button 2
		else if (pb_data == 4) {
			VGA_clear_charbuff_ASM();
		}
		//Push Button 3
		else if (pb_data == 8) {
			VGA_clear_pixelbuff_ASM();
		}
	}
}

void ps2keyboard() {
	//clear screen
	VGA_clear_charbuff_ASM();

	int x=0;
	int y=0;
	int valid=0;
	
	//keyboard data pointer
	char *data;
	while(1){
		//read keyboard data input
		valid = read_PS2_data_ASM(data); 	
		if(valid==1){
			//write corrosponding keyboard make and break keys on x and y 						
			VGA_write_byte_ASM(x,y,*data); 
			x+=3;	
	}
		//start new line if x reaches end
		if(x>79){
			x=0;
			y++;	
		}
		//start new page if page is full
		if(y>59){
			VGA_clear_charbuff_ASM();
			y=0;
		}
	}
}


void audio(){

	int sample_rate = 48000;
	int frequency  = 100;

		while(1){
			int i;
			//write for part 1
			for(i = 0; i < (sample_rate/(frequency * 2));){
				if(write_audio_data_ASM(0x00FFFFFF)) i++;
			}
			//write for part 2
			for(i = 0; i< (sample_rate/(frequency * 2));){
				if(write_audio_data_ASM(0x00000000)) i++;
			}
		}
}

int main() {
	//vga();
	//ps2keyboard();
	audio();
	return 0;
}
