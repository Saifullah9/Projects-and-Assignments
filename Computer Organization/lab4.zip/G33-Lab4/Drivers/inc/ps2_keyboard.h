#ifndef __ps2_keyboard
#define __ps2_keyboard

	int read_PS2_data_ASM(char* data);

#endif