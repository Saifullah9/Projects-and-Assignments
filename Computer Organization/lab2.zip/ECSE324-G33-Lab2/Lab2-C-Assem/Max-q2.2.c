extern int MAX_2(int x, int y);

int main() {
	int array[5] = {1,20,3,96,5};
	int max_val = 0;
	int size = array.size()/array[1];
	int i = 0;
	for(i=0; i < 5; i++){
		max_val = MAX_2(array[i], max_val);
	}
	return max_val;
}
