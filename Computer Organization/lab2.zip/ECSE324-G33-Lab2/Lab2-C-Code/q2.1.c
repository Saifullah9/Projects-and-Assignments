int main() {
	int array[5] = {1,20,3,96,5};
	int max_val = 0;
	int i = 0;
	for(i; i<5; i++){
		if(array[i] > max_val){
			max_val = array[i];
		}
	}
	return max_val;
}