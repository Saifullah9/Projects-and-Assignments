#include <stdio.h>
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/ISRs.h"
#include "./drivers/inc/pushbuttons.h"

#include "./drivers/inc/slider_switches.h"
#include "./drivers/inc/LEDs.h"

int main(){

	int_setup(2, (int []){73, 199});
	//enable push buttons
	enable_PB_INT_ASM(PB0 | PB1 | PB2);

	int time = 0;

	// HPS_TIM_config_t hps_tim_10;

	// hps_tim_10.tim     = TIM0;
	// hps_tim_10.timeout = 10000;
	// hps_tim_10.LD_en   = 1;
	// hps_tim_10.INT_en  = 1;
	// hps_tim_10.enable  = 1;

	// HPS_TIM_config_ASM(&hps_tim_10);
	

	// configure the timer that detects button presses
	//HPS_TIM_config_t hps_tim_pb;
	//HPS_TIM_config_ASM(&hps_tim_pb);

	//default
	int stopped = 1;

	//clearASM
	HEX_clear_ASM(HEX0 | HEX1 | HEX2 | HEX3 | HEX4 | HEX5);
	while(1){	
		if(hps_tim0_int_flag){
			hps_tim0_int_flag = 0;

			//int pb_values = read_PB_edgecap_ASM();
		if(pb_int_flag > 0){
			if(pb_int_flag & 1) {
				stopped = 0;
				//PB_clear_edgecap_ASM(PB0);
			}

			else if(pb_int_flag & 2) {
				stopped = 1;

				//PB_clear_edgecap_ASM(PB1);
			}

			else if(pb_int_flag == 4) {
				time = 0;

				//PB_clear_edgecap_ASM(PB2);
			}
			pb_int_flag = 0;
			}

			if(!stopped) {
				time += 10;
			}
			//limit time
			if(time == 6000000)
				time = 0;
			//calc min seconds and millisec
			int minutes = time / 60000;
			int seconds = (time - (minutes * 60000)) / 1000;
			int milliseconds = time - (minutes * 60000) - (seconds * 1000);

			//to get first digit and second digit
			char minutesFirst = minutes / 10;
			char minutesSecond = minutes % 10;
			//to get first digit and second digit
			char secondsFirst = seconds / 10;
			char secondsSecond = seconds % 10;
			//to get first digit and second digit
			char millisecondsFirst = (milliseconds / 10) / 10;
			char millisecondsSecond = (milliseconds % 100) / 10;


			//write each thing to its corrosponding thing
			HEX_clear_ASM(HEX0);
			HEX_write_ASM(HEX0, millisecondsSecond);

			HEX_clear_ASM(HEX1);
			HEX_write_ASM(HEX1, millisecondsFirst);

			HEX_clear_ASM(HEX2);
			HEX_write_ASM(HEX2, secondsSecond);

			HEX_clear_ASM(HEX3);
			HEX_write_ASM(HEX3, secondsFirst);

			HEX_clear_ASM(HEX4);
			HEX_write_ASM(HEX4, minutesSecond);

			HEX_clear_ASM(HEX5);
			HEX_write_ASM(HEX5, minutesFirst);
		}
		//write ASMS
		write_LEDs_ASM(read_slider_switches_ASM());
	}

	return 0;
}
