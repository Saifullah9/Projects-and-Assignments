#ifndef __LEDS
#define __LEDS

	extern int read_LEDs_ASM();
	extern int write_LEDs_ASM();

#endif
