#include <stdio.h>
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/ISRs.h"
#include "./drivers/inc/pushbuttons.h"

#include "./drivers/inc/slider_switches.h"
#include "./drivers/inc/LEDs.h"

int main(){
	int time = 0;


	//configure timer for button and timer for updating

	//timer1
	HPS_TIM_config_t hps_tim_10;

	hps_tim_10.tim     = TIM0;
	hps_tim_10.timeout = 10000;
	hps_tim_10.LD_en   = 1;
	hps_tim_10.INT_en  = 1;
	hps_tim_10.enable  = 1;

	HPS_TIM_config_ASM(&hps_tim_10);


	//timer2
	HPS_TIM_config_t hps_tim_5;

	hps_tim_5.tim     = TIM1;
	hps_tim_5.timeout = 5000;
	hps_tim_5.LD_en   = 1;
	hps_tim_5.INT_en  = 1;
	hps_tim_5.enable  = 1;

	HPS_TIM_config_ASM(&hps_tim_5);
	//default value is 1
	int stopped = 1;
	
	//clearASM
	HEX_clear_ASM(HEX0 | HEX1 | HEX2 | HEX3 | HEX4 | HEX5);
	while(1){	
		if(HPS_TIM_read_INT_ASM(TIM1)){
			HPS_TIM_clear_INT_ASM(TIM1);
			//read edge cap all time (polling)
			int pb_values = read_PB_edgecap_ASM();
			//button 0 
			if(pb_values & PB0) {
				stopped = 0;

				PB_clear_edgecap_ASM(PB0);
			}
			//button 1
			if(pb_values & PB1) {
				stopped = 1;

				PB_clear_edgecap_ASM(PB1);
			}
			//button 2
			if(pb_values & PB2) {
				time = 0;

				PB_clear_edgecap_ASM(PB2);
			}
		}
		//timer
		if(HPS_TIM_read_INT_ASM(TIM0)){
			HPS_TIM_clear_INT_ASM(TIM0);

			if(!stopped) {
				time += 10;
			}
			//limit time
			if(time == 6000000)
				time = 0;
			//calc min seconds and millisec
			int minutes = time / 60000;
			int seconds = (time - (minutes * 60000)) / 1000;
			int milliseconds = time - (minutes * 60000) - (seconds * 1000);
			//to get first digit and second digit
			char minutesFirst = minutes / 10;
			char minutesSecond = minutes % 10;
			//to get first digit and second digit
			char secondsFirst = seconds / 10;
			char secondsSecond = seconds % 10;
			//to get first digit and second digit
			char millisecondsFirst = (milliseconds / 10) / 10;
			char millisecondsSecond = (milliseconds % 100) / 10;


			//write each thing to its corrosponding thing
			HEX_clear_ASM(HEX0);
			HEX_write_ASM(HEX0, millisecondsSecond);

			HEX_clear_ASM(HEX1);
			HEX_write_ASM(HEX1, millisecondsFirst);

			HEX_clear_ASM(HEX2);
			HEX_write_ASM(HEX2, secondsSecond);

			HEX_clear_ASM(HEX3);
			HEX_write_ASM(HEX3, secondsFirst);

			HEX_clear_ASM(HEX4);
			HEX_write_ASM(HEX4, minutesSecond);

			HEX_clear_ASM(HEX5);
			HEX_write_ASM(HEX5, minutesFirst);
		}
		//write ASMS
		write_LEDs_ASM(read_slider_switches_ASM());
	}

	return 0;
}
