#include <stdio.h>

#include "./drivers/inc/LEDs.h"
#include "./drivers/inc/slider_switches.h"

#include "./drivers/inc/HEX_displays.h"

#include "./drivers/inc/pushbuttons.h"

int main(){

	 while(1) {
	 	//read slider values
		int slider_value = read_slider_switches_ASM();

		//write values on LEDs
		write_LEDs_ASM(slider_value);
		//Hex plus slider value
		int hex_value = 0xF & slider_value;
		//push button values
		int pb_values = 0xF & read_PB_data_ASM();

		//HEX_clear_ASM(HEX0 | HEX1 | HEX2 |HEX3 | HEX4 | HEX5);

		if(!(slider_value & 0x200)) {
			if(pb_values & PB0) {
				HEX_write_ASM(HEX0, hex_value);
			}
			//pushbutton1
			if(pb_values & PB1) {
				HEX_write_ASM(HEX1, hex_value);
			}
			//pushbutton2
			if(pb_values & PB2) {
				HEX_write_ASM(HEX2, hex_value);
			}
			//pushbutton3
			if(pb_values & PB3) {
				HEX_write_ASM(HEX3, hex_value);
			}
			//always flooded
			HEX_flood_ASM(HEX4 | HEX5);	
		}
		else {
			//clear values if slider is clicked
		HEX_clear_ASM(HEX0 | HEX1 | HEX2 |HEX3 | HEX4 | HEX5);
		}	
	}

	return 0;
}
