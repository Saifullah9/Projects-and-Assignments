/*
Lab 5
Michel Kassis
Saifullah Elsayed
*/

#include "./drivers/inc/vga.h"
#include "./drivers/inc/ISRs.h"
#include "./drivers/inc/LEDs.h"
#include "./drivers/inc/audio.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/wavetable.h"
#include "./drivers/inc/pushbuttons.h"
#include "./drivers/inc/ps2_keyboard.h"
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/slider_switches.h"

//screen width initalize
#define SCREEN_WIDTH 319

//initalize our sound frequencies
#define C_FREQUENCY  130.813
#define D_FREQUENCY  146.832
#define E_FREQUENCY  164.814
#define F_FREQUENCY  174.614
#define G_FREQUENCY  195.998
#define A_FREQUENCY  220.000
#define B_FREQUENCY  246.942
#define C2_FREQUENCY 261.626
#define D2_FREQUENCY 293.665
#define E2_FREQUENCY 329.628
#define F2_FREQUENCY 349.228
#define G2_FREQUENCY 391.995
#define A2_FREQUENCY 440.000
#define B2_FREQUENCY 493.883

//Q1 generate signal
int generateSignal(float frequency, double time) {

    int index  = (int)(frequency * time) % 48000;
    return sine[index];
}

typedef enum { false, true } bool;

int main() {

	int_setup(2, (int []){199, 200});

	//time starts at 0
	long time = 0;
	
	//config audio timer
	HPS_TIM_config_t hps_tim_audio;

	hps_tim_audio.tim     = TIM0;
	hps_tim_audio.timeout = 10;
	hps_tim_audio.LD_en   = 1;
	hps_tim_audio.INT_en  = 1;
	hps_tim_audio.enable  = 1;

	HPS_TIM_config_ASM(&hps_tim_audio);

	//config keyboard timer
	HPS_TIM_config_t hps_tim_keyboard;

	hps_tim_keyboard.tim     = TIM1;
	hps_tim_keyboard.timeout = 10000;
	hps_tim_keyboard.LD_en   = 1;
	hps_tim_keyboard.INT_en  = 1;
	hps_tim_keyboard.enable  = 1;

	HPS_TIM_config_ASM(&hps_tim_keyboard);

	//default volume
	int amplitude = 80;

	//by default all buttons = false (not pressed)
	//added octave (from W to O buttons)
	bool a_buttonPressed = false;
	bool s_buttonPressed = false;
	bool d_buttonPressed = false;
	bool f_buttonPressed = false;
	bool j_buttonPressed = false;
	bool k_buttonPressed = false;
	bool l_buttonPressed = false;
	bool semiColon_buttonPressed = false;
	bool w_buttonPressed = false;
	bool e_buttonPressed = false;
	bool r_buttonPressed = false;
	bool u_buttonPressed = false;
	bool i_buttonPressed = false;
	bool o_buttonPressed = false;
	
	//clear screen
	VGA_clear_pixelbuff_ASM();
	
	//ps2 key char input
	char * ps2_key = 0;

	//xAxis for drawing pixel
	float xAxis = 0;

	
	int colourValue = 0;
	while(1){
		long sampleSound = 0;
		//check if keyboard flag is enabled
		if(hps_tim1_int_flag){
			//dsable keyboard flag by default afterwards
			hps_tim1_int_flag = 0;

			//Q2 control keys
			//if a ps2_key is read then enable its bool
			if(read_ps2_data_ASM(ps2_key)){
                if      (*ps2_key == 0x1C) { a_buttonPressed    = true; }
                else if (*ps2_key == 0x1B) { s_buttonPressed    = true; }
                else if (*ps2_key == 0x23) { d_buttonPressed    = true; }
                else if (*ps2_key == 0x2B) { f_buttonPressed    = true; }
                else if (*ps2_key == 0x3B) { j_buttonPressed    = true; }
                else if (*ps2_key == 0x42) { k_buttonPressed    = true; }
                else if (*ps2_key == 0x4B) { l_buttonPressed    = true; }
                else if (*ps2_key == 0x4C) { semiColon_buttonPressed = true; }
				else if (*ps2_key == 0x1D) { w_buttonPressed    = true; }
                else if (*ps2_key == 0x24) { e_buttonPressed    = true; }
                else if (*ps2_key == 0x2D) { r_buttonPressed    = true; }
                else if (*ps2_key == 0x3C) { u_buttonPressed    = true; }
                else if (*ps2_key == 0x43) { i_buttonPressed    = true; }
                else if (*ps2_key == 0x44) { o_buttonPressed    = true; }

                else if (*ps2_key == 0x55) { amplitude = amplitude + 10; } // + (=)
                else if (*ps2_key == 0x4E) { amplitude = amplitude - 10; } // - (_)
				
    			//if a  ps2_key is 0XF0 which is break code
                else if (*ps2_key == 0xF0){
					//if a key is unpressed then disable its bool
                    while(!read_ps2_data_ASM(ps2_key));
                    if      (*ps2_key == 0x1C) { a_buttonPressed    = false; }
                    else if (*ps2_key == 0x1B) { s_buttonPressed    = false; }
                    else if (*ps2_key == 0x23) { d_buttonPressed    = false; }
                    else if (*ps2_key == 0x2B) { f_buttonPressed    = false; }
                    else if (*ps2_key == 0x3B) { j_buttonPressed    = false; }
                    else if (*ps2_key == 0x42) { k_buttonPressed    = false; }
                    else if (*ps2_key == 0x4B) { l_buttonPressed    = false; }
                    else if (*ps2_key == 0x4C) { semiColon_buttonPressed = false; }
					else if (*ps2_key == 0x1D) { w_buttonPressed    = false; }
                	else if (*ps2_key == 0x24) { e_buttonPressed    = false; }
                	else if (*ps2_key == 0x2D) { r_buttonPressed    = false; }
                	else if (*ps2_key == 0x3C) { u_buttonPressed    = false; }
                	else if (*ps2_key == 0x43) { i_buttonPressed    = false; }
                	else if (*ps2_key == 0x44) { o_buttonPressed    = false; }
                		
				}
            }
		}
		
		//check if audio generation flag is enabled
		if(hps_tim0_int_flag){
			//disable it by default
			hps_tim0_int_flag = 0;

			//when bool is enabled, generate signals accordingly
			if(w_buttonPressed) 
			{
				sampleSound += generateSignal(D2_FREQUENCY, time);
			}

			if(e_buttonPressed) 
			{
				sampleSound += generateSignal(E2_FREQUENCY, time);
			}

			if(r_buttonPressed) 
			{
				sampleSound += generateSignal(F2_FREQUENCY, time);
			}

			if(u_buttonPressed) 
			{
				sampleSound += generateSignal(G2_FREQUENCY, time);
			}

			if(i_buttonPressed) 
			{
				sampleSound += generateSignal(A2_FREQUENCY, time);
			}

			if(o_buttonPressed) 
			{
				sampleSound += generateSignal(B2_FREQUENCY, time);
			}

			if(a_buttonPressed) 
			{
				sampleSound += generateSignal(C_FREQUENCY, time);
			}

			if(s_buttonPressed) 
			{
				sampleSound += generateSignal(D_FREQUENCY, time);
			}

			if(d_buttonPressed) 
			{
				sampleSound += generateSignal(E_FREQUENCY, time);
			}

			if(f_buttonPressed) 
			{
				sampleSound += generateSignal(F_FREQUENCY, time);
			}

			if(j_buttonPressed) 
			{
				sampleSound += generateSignal(G_FREQUENCY, time);
			}

			if(k_buttonPressed) 
			{
				sampleSound += generateSignal(A_FREQUENCY, time);
			}

			if(l_buttonPressed) 
			{
				sampleSound += generateSignal(B_FREQUENCY, time);
			}

			if(semiColon_buttonPressed) 
			{
				sampleSound += generateSignal(C2_FREQUENCY, time);
			}
				
			//signal[t] = amplitude * table[index]
			sampleSound *= amplitude;
			
			//Assign right and left to sampleSound signal generated
			if(audio_write_data_ASM(sampleSound, sampleSound)) 
			{
				time++;
				if(time%16 == 0) 
				{
					xAxis +=1;
					if(xAxis > SCREEN_WIDTH) 
					{
						VGA_clear_pixelbuff_ASM();
						xAxis = 0;
					}
				}
				int yAxis = (double)(sampleSound) / (100000000.0) + 119;
				//Q3
				VGA_draw_point_ASM(xAxis, yAxis, colourValue++);
			}
		}
	}

	return 0;
}
